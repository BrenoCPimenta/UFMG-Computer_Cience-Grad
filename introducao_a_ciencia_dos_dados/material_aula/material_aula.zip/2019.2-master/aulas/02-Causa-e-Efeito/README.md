# John Snow

Aula sem notebook, porém algumas leituras interessantes.

Leituras:

1. Capítulo 2 de Inferential Thunking
   https://www.inferentialthinking.com
1. The Book of Why. Judea Pearl. [Capítulo 4]
1. Our sense of Snow: the myth of John Snow in medical geography
   http://www.ph.ucla.edu/epi/snow/socscimed50_923_935_2000.pdf
