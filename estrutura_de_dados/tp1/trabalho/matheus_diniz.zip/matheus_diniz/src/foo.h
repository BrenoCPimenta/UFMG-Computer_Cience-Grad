#ifndef __TP1_ED___
#define __TP1_ED__

int bar();

#endif
